package com.example.mintweight

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mint_weight", Context.MODE_PRIVATE) }
    private val records = mutableListOf<Pair<String, Float>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadRecords()
        refresh()

        findViewById<Button>(R.id.addButton).setOnClickListener { addWeight() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { showHistory() }
    }

    private fun loadRecords() {
        records.clear()
        val raw = prefs.getString("records", "") ?: ""
        if (raw.isNotBlank()) raw.split("|").forEach {
            val p = it.split(",")
            if (p.size == 2) p[1].toFloatOrNull()?.let { w -> records.add(p[0] to w) }
        }
    }

    private fun saveRecords() {
        prefs.edit().putString("records", records.joinToString("|") { "${it.first},${it.second}" }).apply()
    }

    private fun addWeight() {
        val input = EditText(this)
        input.hint = "例如 72.6"
        input.inputType = 8194
        AlertDialog.Builder(this).setTitle("记录今天体重")
            .setMessage("单位：kg")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                input.text.toString().trim().toFloatOrNull()?.let { w ->
                    val date = SimpleDateFormat("MM/dd", Locale.getDefault()).format(Date())
                    records.removeAll { it.first == date }
                    records.add(date to w)
                    records.sortBy { it.first }
                    saveRecords()
                    refresh()
                } ?: Toast.makeText(this, "请输入正确的数字", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun refresh() {
        val current = records.lastOrNull()?.second
        findViewById<TextView>(R.id.currentWeight).text = current?.let { "%.1f kg".format(it) } ?: "--.- kg"
        if (records.size >= 2) {
            val d = records.last().second - records[records.size - 2].second
            findViewById<TextView>(R.id.changeText).text = if (d < 0) "↓ %.1f kg  比上次".format(-d) else "↑ %.1f kg  比上次".format(d)
        }
        if (records.size >= 2) {
            val total = records.last().second - records.first().second
            findViewById<TextView>(R.id.totalChange).text = "%+.1f kg".format(total)
        }
        records.minOfOrNull { it.second }?.let { findViewById<TextView>(R.id.minWeight).text = "%.1f kg".format(it) }
        findViewById<TextView>(R.id.chart).text = makeChart()
    }

    private fun makeChart(): String {
        if (records.isEmpty()) return "记录数据后，这里会显示你的体重曲线"
        if (records.size == 1) return "${records[0].first}    ●  %.1f kg".format(records[0].second)
        val min = records.minOf { it.second }
        val max = records.maxOf { it.second }
        val rows = 5
        val sb = StringBuilder()
        for (r in 0 until rows) {
            val threshold = max - (max - min) * r / (rows - 1).coerceAtLeast(1)
            sb.append("%.1f  ".format(threshold))
            records.forEach { (_, w) -> sb.append(if (w >= threshold - (max-min)/8) "● " else "  ") }
            sb.append("\n")
        }
        sb.append("      ").append(records.joinToString("  ") { it.first })
        return sb.toString()
    }

    private fun showHistory() {
        val text = if (records.isEmpty()) "还没有体重记录。" else
            records.asReversed().joinToString("\n") { "${it.first}     %.1f kg".format(it.second) }
        AlertDialog.Builder(this).setTitle("历史记录").setMessage(text)
            .setPositiveButton("关闭", null).show()
    }
}
